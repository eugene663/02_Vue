import { add } from './13_02-19-module.mjs';

console.log(add(4));
