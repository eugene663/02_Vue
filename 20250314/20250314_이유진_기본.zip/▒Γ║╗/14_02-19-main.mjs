import getBase, { add } from './14_02-19-module.mjs';
console.log(add(4));
console.log(getBase());
